import apiSlice from '../api/apiSlice';

export const tasksApi = apiSlice.injectEndpoints({
  /* tagTypes: ['getTasks', 'addTask', 'singleTask', 'updateTask'], */

  endpoints: (builder) => ({
    addTask: builder.mutation({
      query: (data) => ({
        url: '/tasks',
        method: 'POST',
        body: data,
      }),

      /* providesTags: ['addTask'],
      invalidatesTags: ['getTasks'], */
    }),

    getTasks: builder.query({
      query: () => '/tasks',

      /*  providesTags: ['getTasks'], */
      // invalidatesTags: ['addTask', 'singleTask'],
    }),

    getSingleTask: builder.query({
      query: (id) => `/tasks/${id}`,

      providesTags: (result, error, arg) => [
        { type: 'singleTask', id: arg.id },
      ],
    }),

    updateTask: builder.mutation({
      query: ({ id, data }) => ({
        url: `/tasks/${id}`,
        method: 'PATCH',
        body: data,
      }),

      async onQueryStarted({ id, data }, { queryFulfilled, dispatch }) {
        const patchResult = dispatch(
          tasksApi.util.updateQueryData('getTasks', undefined, (draft) => {
            const draftTasks = draft.find((task) => task.id == arg.id);
            if (draftTasks) {
              draftTasks.taskName = data.taskName;
              draftTasks.teamMember = data.teamMember;
              draftTasks.project = data.project;
              draftTasks.deadline = data.deadline;
              draftTasks.deadline = data.deadline;
            }
            console.log(draft);
            console.log(id);
          }),
        );

        try {
          await queryFulfilled;
        } catch (error) {
          patchResult.undo();
        }
      },

      // await queryFulfilled; // wait for the query to be fulfilled
      // console.log(id);
      // dispatch(fetchResult);

      // providesTags: ['updateTask'],
      // invalidatesTags: ['getTasks'],
      // invalidatesTags: ['singleTask'],

      // async onQu
      /* async onQueryStarted(arg, { queryFulfilled, dispatch }) {
        const patchResult = dispatch(
          apiSlice.util.updateQueryData('getTasks', arg.data, (draft) => {
            const draftTasks = draft.find((task) => task.id == arg.id);
            if (draftTasks) {
              draftTasks.taskName = arg.data.taskName;
              draftTasks.teamMember = arg.data.teamMember;
              draftTasks.project = arg.data.project;
              draftTasks.deadline = arg.data.deadline;
              draftTasks.deadline = arg.data.deadline;
            }
            console.log(draftTasks);
          }),
        );
        try {
          // patchResult();
          const tasks = await queryFulfilled;

          if (tasks?.data?.id) {
            // dispatch(tasksApi.endpoints.addTask.ini)
          }
        } catch (error) {
          patchResult.undo();
        }
      }, */

      /* async onQueryStarted(arg, { queryFulfilled, dispatch }) {
        await queryFulfilled;
        const fetchResult = tasksApi.util.updateQueryData(
          'getTasks',
          // arg.id,
          (draft) => {
            const draftTasks = draft.find((task) => task.id == arg.id);
            if (draftTasks) {
              draftTasks.taskName = arg.data.taskName;
              draftTasks.teamMember = arg.data.teamMember;
              draftTasks.project = arg.data.project;
              draftTasks.deadline = arg.data.deadline;
            }
            console.log(draft);
          },
        );

        const patchResult = dispatch(fetchResult);
        try {
          console.log(0);
          // await queryFulfilled;
        } catch (error) {
          console.log(1);
          patchResult.undo();
        }
      }, */
    }),
  }),
});

export const {
  useAddTaskMutation,
  useGetTasksQuery,
  useGetSingleTaskQuery,
  useUpdateTaskMutation,
} = tasksApi;

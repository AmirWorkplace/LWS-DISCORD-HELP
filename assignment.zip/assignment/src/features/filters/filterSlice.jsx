import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  searchValue: '',
};

const filtersSlice = createSlice({
  name: 'filters',
  initialState,
  reducers: {
    searched: (state, action) => {
      state.searchValue = action.payload;
    },
  },
});

export default filtersSlice.reducer;
export const { searched } = filtersSlice.actions;

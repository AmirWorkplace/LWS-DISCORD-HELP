import apiSlice from '../api/apiSlice';

export const projectsApi = apiSlice.injectEndpoints({
  tagTypes: ['getProjectsApi'],

  endpoints: (builder) => ({
    getProjects: builder.query({
      query: () => '/projects',
      providesTags: ['getProjectsApi'],
    }),
  }),
});

export const { useGetProjectsQuery } = projectsApi;

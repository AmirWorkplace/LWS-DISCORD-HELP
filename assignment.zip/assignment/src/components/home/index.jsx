import React from 'react';

export const Home = ({ children }) => {
  return <div className="container relative">{children}</div>;
};

export default Home;

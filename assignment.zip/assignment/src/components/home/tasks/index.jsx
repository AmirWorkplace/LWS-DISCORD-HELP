import React from 'react';
import { avatars } from '../../../assets';
import { useGetTasksQuery } from '../../../features/tasks/tasksApi';
import Task from './Task';

// const actionBtn = 'delete' useGetTasksQuery

export const TaskLits = () => {
  const { data: tasks, isLoading, isError, error } = useGetTasksQuery();

  let content = null;

  if (isLoading) content = <p className="loading">Loading...</p>;
  if (!isLoading && isError) content = <p className="error">{error}</p>;
  if (!isLoading && !isError && tasks?.length === 0)
    content = <p className="not-found">There was no Projects Founded!</p>;
  if (!isLoading && !isError && tasks?.length > 0)
    content = tasks.map((task) => <Task key={task.id} task={task} />);

  return (
    <div className="lws-task-list">
      {content}
      {/* <Task
        status="complete"
        deadline="2023-1-4"
        taskTitle="Last over need 15 runs"
        projectName="Scoreboard"
        name="Sumit Saha"
        colorClass="color-scoreboard"
        avater={avatars.sumit}
      />
      <Task
        status="complete"
        deadline="2023-2-1"
        taskTitle="Last over need 15 runs"
        projectName="Scoreboard"
        name="Ferdous Hassan"
        colorClass="color-flight"
        avater={avatars.ferdous}
      />
      <Task
        status="complete"
        deadline="2023-05-17"
        taskTitle="Last over need 15 runs"
        projectName="Scoreboard"
        name="Saad Hassan"
        colorClass="color-productCart"
        avater={avatars.sadh}
      />
      <Task
        status="complete"
        deadline="2023-12-14"
        taskTitle="Last over need 15 runs"
        projectName="Scoreboard"
        name="Salahuddin Hassan"
        colorClass="color-bookstore"
        avater={avatars.salahuddin}
      /> */}
    </div>
  );
};

export default TaskLits;

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { icons } from '../../../assets';

export const Task = ({ task }) => {
  // const { deadline, projectName, name, taskTitle, avater, status, colorClass } =
  const { id, taskName, teamMember, project, deadline, status } = task;

  const { id: projectId, projectName, colorClass } = project;
  const { id: teamMemberId, name, avatar } = teamMember;

  const navigate = useNavigate();
  const [Status, setStatus] = useState(status);

  const months = [
    '0-Index',
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  const date = deadline.split('-');
  const month = Number(date[1]);
  const day = date[2];

  const statusChangeHandler = (e) => {
    setStatus(e.target.value);
  };

  const taskEditHandler = () => {
    navigate(`/edittask/${id}`);
  };

  return (
    <div className="lws-task">
      <div className="flex items-center gap-2 text-slate">
        <h2 className="lws-date">{day}</h2>
        <h4 className="lws-month">{months[month]}</h4>
      </div>

      <div className="lws-taskContainer">
        <h1 className="lws-task-title">{taskName}</h1>
        <span className={`lws-task-badge ${colorClass}`}>{projectName}</span>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <img src={avatar} className="team-avater" />
          <p className="lws-task-assignedOn">{name}</p>
        </div>

        {Status === 'complete' ? (
          <button className="lws-delete">{icons.deleteSVG}</button>
        ) : (
          <button onClick={taskEditHandler} className="lws-edit">
            {icons.editSVG}
          </button>
        )}

        <select
          className="lws-status"
          value={Status}
          onChange={statusChangeHandler}
        >
          <option value="pending">Pending</option>
          <option value="inProgress">In Progress</option>
          <option value="complete">Completed</option>
        </select>
      </div>
    </div>
  );
};

export default Task;
/*


  {
    "taskName": "Task One",
    "teamMember": {
      "name": "Saad Hasan",
      "avatar": "/images/avatars/sadh.png",
      "id": 1
    },
    "project": {
      "id": 1,
      "projectName": "Scoreboard",
      "colorClass": "color-scoreboard"
    },
    "deadline": "2023-03-15",
    "id": 1,
    "status": "inProgress"
  },



 */

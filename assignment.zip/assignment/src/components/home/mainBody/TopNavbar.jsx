import React from 'react';
import { Link } from 'react-router-dom';
import { icons } from '../../../assets';

export const TopNavbar = () => {
  return (
    <div className="justify-between mb-10 space-y-2 md:flex md:space-y-0">
      <Link to="/createtask" className="lws-addnew group">
        {icons.plusSVG}

        <span className="group-hover:text-indigo-500">Add New</span>
      </Link>
    </div>
  );
};

export default TopNavbar;

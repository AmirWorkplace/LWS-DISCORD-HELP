import React from 'react';

export const MainBody = ({ children }) => {
  return (
    <div className="lg:pl-[16rem] 2xl:pl-[23rem]">
      <main className="relative z-20 max-w-3xl mx-auto rounded-lg xl:max-w-none">
        {children}
      </main>
    </div>
  );
};

export default MainBody;

import React from 'react';
import TeamMember from './TeamMember';
import { avatars } from '../../../../assets';
import { useGetTeamQuery } from '../../../../features/team/teamApi';

export const TeamMemberContainer = () => {
  const { data: teamMembers, isLoading, isError, error } = useGetTeamQuery();

  let content = null;

  if (isLoading) content = <p className="loading">Loading...</p>;
  if (!isLoading && isError) content = <p className="error">{error}</p>;
  if (!isLoading && !isError && teamMembers?.length === 0)
    content = <p className="not-found">There was no Projects Founded!</p>;
  if (!isLoading && !isError && teamMembers?.length > 0)
    content = teamMembers.map((member) => (
      <TeamMember key={member.id} member={member} />
    ));

  return (
    <div className="mt-8">
      <h3 className="text-xl font-bold">Team Members</h3>
      <div className="mt-3 space-y-4">
        {content}
        {/* <TeamMember name="Sumit Saha" avater={avatars.sumit} />
        <TeamMember name="Sadh Hasan" avater={avatars.sadh} />
        <TeamMember name="Akash Ahmed" avater={avatars.akash} />
        <TeamMember name="Md Salahuddin" avater={avatars.salahuddin} />
        <TeamMember name="Riyadh Hassan" avater={avatars.riyadh} />
        <TeamMember name="Ferdous Hassan" avater={avatars.ferdous} />
        <TeamMember name="Arif Almas" avater={avatars.almas} /> */}
      </div>
    </div>
  );
};

export default TeamMemberContainer;

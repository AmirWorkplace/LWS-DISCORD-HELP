import React, { useState } from 'react';

export const CheckBox = ({ project }) => {
  const [isChecked, setChecked] = useState(true);
  const { projectName, colorClass } = project;

  return (
    <div className="checkbox-container">
      <input
        type="checkbox"
        className={colorClass}
        checked={isChecked}
        onChange={(e) => setChecked(e.target.checked)}
      />
      <p className="label">{projectName}</p>
    </div>
  );
};

export default CheckBox;

import React from 'react';
import { useGetProjectsQuery } from '../../../../features/projects/projectsApi';
import CheckBox from './CheckBox';

export const CheckBoxContainer = () => {
  const { data: projects, isLoading, isError, error } = useGetProjectsQuery();

  let content = null;

  if (isLoading) content = <p className="loading">Loading...</p>;
  if (!isLoading && isError) content = <p className="error">{error}</p>;
  if (!isLoading && !isError && projects?.length === 0)
    content = <p className="not-found">There was no Projects Founded!</p>;
  if (!isLoading && !isError && projects?.length > 0)
    content = projects.map((project) => (
      <CheckBox key={project.id} project={project} />
    ));

  return (
    <div>
      <h3 className="text-xl font-bold">Projects</h3>
      <div className="mt-3 space-y-4">{content}</div>
    </div>
  );
};

export default CheckBoxContainer;

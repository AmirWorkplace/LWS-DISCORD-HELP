import React from 'react';
import CheckBoxContainer from './checkbox/CheckBoxContainer';
import TeamMemberContainer from './teamMember/TeamMemberContainer';

export const Sidebar = () => {
  return (
    <div className="sidebar">
      <CheckBoxContainer />
      <TeamMemberContainer />
    </div>
  );
};

export default Sidebar;

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAddTaskMutation } from '../../features/tasks/tasksApi';

export const AddForm = ({ projects, team }) => {
  const navigate = useNavigate();
  const [addTask, { isSuccess }] = useAddTaskMutation();

  const [project, SetProject] = useState('{}');
  const [teamMember, setTeamMember] = useState('{}');
  const [taskName, setTaskName] = useState('');
  const [deadline, setDeadline] = useState('');
  const [required, setRequired] = useState(false);

  function reset() {
    SetProject('{}');
    setTeamMember('{}');
    setTaskName('');
    setDeadline('');
  }

  function createTaskHandler(event) {
    event.preventDefault();

    if (
      taskName === '' ||
      deadline === '' ||
      project === '{}' ||
      teamMember === '{}'
    ) {
      setRequired(true);
    } else {
      addTask({
        taskName,
        deadline,
        status: 'inProgress',
        project: JSON.parse(project),
        teamMember: JSON.parse(teamMember),
      });

      setRequired(false);
      reset();
    }
  }

  useEffect(() => {
    isSuccess && navigate('/');
  }, [isSuccess]);

  return (
    <form className="space-y-6" onSubmit={createTaskHandler}>
      <div className="fieldContainer">
        <label htmlFor="lws-taskName">Task Name</label>
        <input
          type="text"
          name="taskName"
          id="lws-taskName"
          required
          placeholder="Implement RTK Query"
          value={taskName}
          onChange={(e) => setTaskName(e.target.value)}
        />
      </div>

      <div className="fieldContainer">
        <label>Assign To</label>
        <select
          name="teamMember"
          id="lws-teamMember"
          value={project}
          onChange={(e) => SetProject(e.target.value)}
          required
        >
          <option hidden>Select Job</option>
          {projects.map((project) => (
            <option
              key={project.id}
              value={JSON.stringify({
                id: project.id,
                colorClass: project.colorClass,
                projectName: project.projectName,
              })}
            >
              {project.projectName}
            </option>
          ))}
        </select>
      </div>
      <div className="fieldContainer">
        <label htmlFor="lws-projectName">Project Name</label>
        <select
          id="lws-projectName"
          name="projectName"
          value={teamMember}
          onChange={(e) => setTeamMember(e.target.value)}
          required
        >
          <option hidden>Select Project</option>
          {team.map((member) => (
            <option
              key={member.id}
              value={JSON.stringify({
                id: member.id,
                name: member.name,
                avatar: member.avatar,
              })}
            >
              {member.name}
            </option>
          ))}
        </select>
      </div>

      <div className="fieldContainer">
        <label htmlFor="lws-deadline">Deadline</label>
        <input
          type="date"
          name="deadline"
          id="lws-deadline"
          value={deadline}
          onChange={(e) => setDeadline(e.target.value)}
          required
        />
      </div>

      <div className="text-right">
        <button type="submit" className="lws-submit">
          Save
        </button>
      </div>
      <div>
        {required && <p className="error">Please required all the fields!</p>}
      </div>
    </form>
  );
};

export default AddForm;
/*

  <option>Sadh Hasan</option>
  <option>Akash Ahmed</option>
  <option>Md Salahuddin</option>
  <option>Riyadh Hassan</option>
  <option>Ferdous Hassan</option>
  <option>Arif Almas</option>

  <option>Scoreboard</option>
  <option>Flight Booking</option>
  <option>Product Cart</option>
  <option>Book Store</option>
  <option>Blog Application</option>
  <option>Job Finder</option>

*/

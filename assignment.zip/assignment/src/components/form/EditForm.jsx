import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  useUpdateTaskMutation,
  useGetSingleTaskQuery,
} from '../../features/tasks/tasksApi';

export const EditForm = ({ projects, team }) => {
  const navigate = useNavigate();
  const { taskId } = useParams('taskId');

  const [updateTask, { isSuccess, error }] = useUpdateTaskMutation();
  const {
    data: singleTask,
    isLoading,
    isError,
  } = useGetSingleTaskQuery(taskId);

  let content = {};
  if (isLoading) content = {};
  if (!isLoading && isError) content = {};
  if (!isLoading && !isError && !singleTask?.id) content = {};
  if (!isLoading && !isError && singleTask?.id) content = singleTask;

  const {
    id: singleTaskId,
    taskName: singleTaskName,
    teamMember: singleTeamMember,
    project: singleProject,
    deadline: singleDeadline,
    status: singleStatus,
  } = content;

  const [project, setProject] = useState('{}');
  const [deadline, setDeadline] = useState('');
  const [taskName, setTaskName] = useState('');
  const [required, setRequired] = useState(false);
  const [teamMember, setTeamMember] = useState('{}');

  useEffect(() => {
    setTaskName(singleTaskName);
    setDeadline(singleDeadline);
    setProject(JSON.stringify(singleProject));
    setTeamMember(JSON.stringify(singleTeamMember));
  }, [content, singleTask]);

  function createTaskHandler(event) {
    event.preventDefault();

    updateTask({
      id: singleTaskId,
      data: {
        taskName,
        deadline,
        status: 'inProgress',
        project: JSON.parse(project),
        teamMember: JSON.parse(teamMember),
      },
    });

    setRequired(false);
  }

  useEffect(() => {
    isSuccess && navigate('/');
  }, [isSuccess]);

  return (
    <form className="space-y-6" onSubmit={createTaskHandler}>
      <div className="fieldContainer">
        <label htmlFor="lws-taskName">Task Name</label>
        <input
          type="text"
          name="taskName"
          id="lws-taskName"
          required
          placeholder="Implement RTK Query"
          value={taskName}
          onChange={(e) => setTaskName(e.target.value)}
        />
      </div>

      <div className="fieldContainer">
        <label>Assign To</label>
        <select
          name="teamMember"
          id="lws-teamMember"
          value={project}
          onChange={(e) => setProject(e.target.value)}
          required
        >
          <option hidden value={JSON.stringify(singleProject)}>
            {singleProject?.projectName}
          </option>
          {projects.map((project) => (
            <option
              key={project.id}
              value={JSON.stringify({
                id: project.id,
                colorClass: project.colorClass,
                projectName: project.projectName,
              })}
            >
              {project.projectName}
            </option>
          ))}
        </select>
      </div>
      <div className="fieldContainer">
        <label htmlFor="lws-projectName">Project Name</label>
        <select
          id="lws-projectName"
          name="projectName"
          value={teamMember}
          onChange={(e) => setTeamMember(e.target.value)}
          required
        >
          <option hidden value={JSON.stringify(singleTeamMember)}>
            {singleTeamMember?.name}
          </option>
          {team.map((member) => (
            <option
              key={member.id}
              value={JSON.stringify({
                id: member.id,
                name: member.name,
                avatar: member.avatar,
              })}
            >
              {member.name}
            </option>
          ))}
        </select>
      </div>

      <div className="fieldContainer">
        <label htmlFor="lws-deadline">Deadline</label>
        <input
          type="date"
          name="deadline"
          id="lws-deadline"
          value={deadline}
          onChange={(e) => setDeadline(e.target.value)}
          required
        />
      </div>

      <div className="text-right">
        <button type="submit" className="lws-submit">
          Update
        </button>
      </div>
      <div>
        {required && <p className="error">Please required all the fields!</p>}
      </div>
    </form>
  );
};

export default EditForm;

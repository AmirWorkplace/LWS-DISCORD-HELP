import React from 'react';
import EditForm from './EditForm';
import { useGetTeamQuery } from '../../features/team/teamApi';
import { useGetProjectsQuery } from '../../features/projects/projectsApi';

export const EditTask = () => {
  const {
    data: teamMember,
    isLoading: isLoadingTeam,
    isError: isErrorTeam,
  } = useGetTeamQuery();

  const {
    data: projects,
    isLoading: isLoadingProjects,
    isError: isErrorProjects,
  } = useGetProjectsQuery();

  let content = null;

  if (isLoadingTeam && isLoadingProjects) {
    content = <p className="loading">Loading...</p>;
  }

  if (!isLoadingTeam && isErrorTeam && !isLoadingProjects && isErrorProjects) {
    content = <p className="error">There is an Error Occurred!</p>;
  }

  if (
    !isLoadingTeam &&
    !isErrorTeam &&
    !isLoadingProjects &&
    !isErrorProjects &&
    projects?.length === 0 &&
    teamMember?.length === 0
  ) {
    content = <p className="not-found">There was no Projects Founded!</p>;
  }

  if (
    !isLoadingTeam &&
    !isErrorTeam &&
    !isLoadingProjects &&
    !isErrorProjects &&
    projects?.length > 0 &&
    teamMember?.length > 0
  ) {
    content = <EditForm projects={projects} team={teamMember} />;
  }

  return (
    <div className="container relative">
      <main className="relative z-20 max-w-3xl mx-auto rounded-lg xl:max-w-none">
        <h1 className="mt-4 mb-8 text-3xl font-bold text-center text-gray-800">
          Edit Task for Your Team
        </h1>
        <div className="justify-center mb-10 space-y-2 md:flex md:space-y-0">
          {content}
        </div>
      </main>
    </div>
  );
};

export default EditTask;

import React, { useState } from 'react';
import Home from './components/home';
import Navbar from './components/Navbar';
import TaskLits from './components/home/tasks';
import Sidebar from './components/home/sidebar';
import MainBody from './components/home/mainBody';
import CreateTask from './components/form/CreateTask';
import TopNavbar from './components/home/mainBody/TopNavbar';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import EditTask from './components/form/EditTask';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route
          path="/"
          element={
            <Home>
              <Sidebar />
              <MainBody>
                <TopNavbar />
                <TaskLits />
              </MainBody>
            </Home>
          }
        />

        <Route path="/createtask" element={<CreateTask />} />
        <Route path="/edittask/:taskId" element={<EditTask />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
